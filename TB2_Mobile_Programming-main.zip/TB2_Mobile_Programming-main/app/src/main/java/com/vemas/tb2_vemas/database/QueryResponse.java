package com.vemas.tb2_vemas.database;

public interface QueryResponse<T> {
    void onSuccess(T data);
    void onFailure(String message);
}