package com.vemas.tb2_vemas.features.subject_crud;

public interface SubjectCrudListener {
    void onSubjectListUpdate(boolean isUpdate);
}
