package com.vemas.tb2_vemas.features.taken_subject_crud;

public interface TakenSubjectCrudListener {
    void onTakenSubjectUpdated(boolean isUpdated);
}
